<?php
   $result = $this->db->get_where('user_master', array('id' => $this->session->userdata('id')))->row();
?>
<footer>

   <div class="container">
      <div class="top-foot">
         <!--<div class="bfh-selectbox bfh-languages" data-language="en_US" data-available="en_US,fr_CA,es_MX" data-flags="true">
         </div>-->
         <div class="row">
             <div class="col-md-6">
                <ul class="comon-foot">
                  <li> <a href="#"> ©2020 OnlyFans </a> </li>
                  <li> <a href="#"> Blog </a> </li>
                  <li> <a href="#"> Twitter </a> </li>
                </ul> 
             </div>
             <div class="col-md-6">
                <div class="link-foot">
                    <ul>
                      <li>  <a href="#"> Terms & Conditions </a> </li>
                      <li> <a href="#"> Contact us </a> </li>
                      <li> <a href="#"> Affiliates / Referrals </a> </li>
                      <li> <a href="#"> Blog  </a> </li>
                    </ul>
                 </div>
             </div>
             
         </div>
         
         
      </div>
   </div>
</footer>

<div id="slide-menu"> 
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" id="close-menu" class="closebtn" onclick="closeNav()">&times;</a>

        <div class="user-images-part">
          <?php if($result->portfolio_image!="") { ?>
          <img src="<?php echo base_url();?>uploads/<?=$result->portfolio_image?>" alt="pic3">
          <?php } else {?>
          <img src="<?php echo base_url();?>assets/images/avatar.png" alt="pic3" width="">
          <?php }?>           
        </div>
        <div class="left-nav-top">
           
           <div class="user-pic">
              <div class="top-user">
                  <div class="active-text">
                       <h5><?php echo $result->displayname;?></h5>
                       <h6><?php echo $result->email;?></h6>
                   </div>
                  <div class="dropdown">
                          
                      <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         <i class="fas fa-angle-down"></i> 
                      </a>
                      
                     
                  </div>
               </div>   
                  
              <div class="comon-text"> <p> <span> 0 </span> Fans</p> 
              <p> <span> 0 </span> Follow </p> </div>
           </div>    
         
        </div>
        <ul class="sub-menu-d1">
          <li> <a href="<?php echo base_url()?>accountsetting"> <span> <i class="far fa-user"></i> </span> My profile </a> </li>
          <li> <a href="#"> <span> <i class="far fa-bookmark"></i> </span> Bookmarks </a> </li>
          <li> <a href="<?php echo base_url()?>fanlisting"> <span> <i class="fas fa-list"></i> </span> List </a> </li>
          <li> <a href="#"> <span> <i class="fas fa-cog"></i> </span> Settings </a> </li>
          <li> <a href="#"> <span> <i class="far fa-credit-card"></i> </span> Your Cards </a> </li>
          <li> <a href="#"> <span> <i class="fas fa-university"></i> </span> Add Bank </a> </li>
          <li> <a href="#"> <span> <i class="far fa-question-circle"></i> </span> Hepls & Support </a> </li>
          <li> <a href="<?php echo base_url()?>home/user_logout"> <span> <i class="fas fa-sign-out-alt"></i> </span> Logout </a> </li>
        </ul>

      </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Quick demo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <iframe width="100%" height="315" src="https://www.youtube.com/embed/c83-7MR_aL0?start=3" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
      
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js" ></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js" ></script>
<!--counter js------------->
<script src="<?php echo base_url();?>assets/js/coustom.js"></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/js/owl.carousel.min.js'></script>
<!--<script src="js/bootstrap-formhelpers.min.js"></script>
--> 
<script>
 $('.dropdown').on('show.bs.dropdown', function(e){
  $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
});

$('.dropdown').on('hide.bs.dropdown', function(e){
  $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
});
</script>
<script>
$(document).ready(function() {
  $('#slid-menu-d1').click(function() {
  document.getElementById("myBtn").disabled = true;
  });
});
</script>
<script>
  $(document).ready(function() {
  $(".navbar button").click(function() {
    $(".navbar-toggler-icon").toggleClass("active");
  });
  });
</script>

<script> 
  function myGeeks() { 
    var x = document.getElementById("GFG"); 
      
    if (x.innerHTML === "1 people") { 
      x.innerHTML = "0 people"; 
    } else { 
      x.innerHTML = "1 people"; 
    } 
  } 
</script>
<script> 
  function myfee() { 
    var x = document.getElementById("my"); 
      
    if (x.innerHTML === "2 people") { 
      x.innerHTML = "1 people"; 
    } else { 
      x.innerHTML = "2 people"; 
    } 
  } 
</script> 

<script>
$('.modal-child').on('show.bs.modal', function () {
    var modalParent = $(this).attr('data-modal-parent');
    $(modalParent).css('opacity', 0);
});
 
$('.modal-child').on('hidden.bs.modal', function () {
    var modalParent = $(this).attr('data-modal-parent');
    $(modalParent).css('opacity', 1);
});
</script>
<script type="text/javascript">
 $(document).ready(function(){
   
   $("#pw").change(function(){
    
     var xx = $("#pw").val();
     
     if(xx.length < 8)
     {
       $("#xv").html('Password must be greater than 8!');
     }

   });

 });


function display(input) {
	
   if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(event) {
         $('#myimg').attr('src', event.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
}

function proimage(input) {
	
   if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(event) {
         $('#proimg').attr('src', event.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
}

$("#imag").change(function() {
   $("#myimg").show();
   $("#a1").hide();
   $("#a2").hide();
   display(this);
});

$("#imag2").change(function() {
   $("#proimg").show();
   $("#p1").hide();
   $("#p2").hide();
   proimage(this);
});

</script>

<script>
$(document).ready(function() {
  $('#slid-menu-d1').click(function() {
	document.getElementById("myBtn").disabled = true;
  });
});
</script>
<script>
  $(document).ready(function() {
	$(".navbar button").click(function() {
	  $(".navbar-toggler-icon").toggleClass("active");
	});
  });
</script>

<script>
 $('.dropdown').on('show.bs.dropdown', function(e){
  $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
});

$('.dropdown').on('hide.bs.dropdown', function(e){
  $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
});
</script>
<script>
$(document).ready(function() {
  $('#slid-menu-d1').click(function() {
	document.getElementById("myBtn").disabled = true;
  });
});
</script>

<script>
function readURL(input, imgControlName) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $(imgControlName).attr('src', e.target.result);
    }
    reader.readAsDataURL(input.files[0]);
  }
}

$("#imag-post").change(function() {
  // add your logic to decide which image control you'll use
  var imgControlName = "#ImgPreview-post";
  readURL(this, imgControlName);
  $('.preview1').addClass('it');
  $('.btn-rmv1').addClass('rmv');
});

$("#removeImage1-post").click(function(e) {
  e.preventDefault();
  $("#imag-post").val("");
  $("#ImgPreview-post").attr("src", "");
  $('.preview1').removeClass('it');
  $('.btn-rmv1').removeClass('rmv');
});

</script>

<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js" type="text/javascript"></script>
</body>
</html>