<?php 
if($this->session->userdata('id')=="")
{
redirect("/");
}
?>
<header>
      <div class="top-area-d1">
         <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto w-100">
                      <li class="nav-item active">
                        <a class="nav-link" href="<?php echo base_url();?>dashboard"><span class="flaticon-home"></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#"><span class="flaticon-notification"></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo base_url();?>addpost"><span class="flaticon-add"></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#"><span class="flaticon-messenger"></span></a>
                      </li>
                      <li class="nav-item">
                        <a href="#" id="slid-menu-d1" class="user-link"><span class="flaticon-user"></span></a>
                      </li>
                </ul>
              </div>
            </nav>
         </div>
      </div>
   </header>