-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2020 at 01:07 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mytamil`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_master`
--

CREATE TABLE `admin_master` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_master`
--

INSERT INTO `admin_master` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'admin@mytamilevents.com', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `cat_icon` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`id`, `category_name`, `cat_icon`) VALUES
(8, 'sumana barui', 'Jellyfish.jpg'),
(9, 'sumana ', 'Koala.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `events_list`
--

CREATE TABLE `events_list` (
  `id` int(11) NOT NULL,
  `event_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events_list`
--

INSERT INTO `events_list` (`id`, `event_name`) VALUES
(3, 'Reception'),
(4, 'birthday'),
(6, 'Mehendi / Sangeeth'),
(7, 'Private Party');

-- --------------------------------------------------------

--
-- Table structure for table `event_master`
--

CREATE TABLE `event_master` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_title` varchar(255) NOT NULL,
  `date_of_event` varchar(255) NOT NULL,
  `event_list` varchar(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `guest_no` varchar(25) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_master`
--

INSERT INTO `event_master` (`id`, `user_id`, `event_title`, `date_of_event`, `event_list`, `country`, `guest_no`, `description`) VALUES
(5, 15, 'aa', '20 dec', 'a', 'a', 'a', 'a'),
(6, 13, '13', '20 dec', 'a', 'aa', 'aa', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_master`
--

CREATE TABLE `feedback_master` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `post_date` int(11) NOT NULL,
  `rating` varchar(25) NOT NULL,
  `feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback_master`
--

INSERT INTO `feedback_master` (`id`, `project_id`, `business_id`, `client_id`, `post_date`, `rating`, `feedback`) VALUES
(1, 7, 13, 13, 2020, '12', 'aaa'),
(2, 7, 13, 13, 2020, '12', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `locations_list`
--

CREATE TABLE `locations_list` (
  `id` int(11) NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations_list`
--

INSERT INTO `locations_list` (`id`, `location`) VALUES
(2, 'howrah');

-- --------------------------------------------------------

--
-- Table structure for table `project_master`
--

CREATE TABLE `project_master` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `project_expiry` varchar(100) NOT NULL,
  `project_dedline` varchar(100) NOT NULL,
  `project_type` varchar(100) NOT NULL,
  `project_price` varchar(50) NOT NULL,
  `project_details` longtext NOT NULL,
  `project_location` varchar(255) NOT NULL,
  `country` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project_master`
--

INSERT INTO `project_master` (`id`, `user_id`, `job_title`, `category`, `project_expiry`, `project_dedline`, `project_type`, `project_price`, `project_details`, `project_location`, `country`) VALUES
(7, 15, 'a', 12, 'a', 'a', 'a', 'a', 'a', 'aa', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `rate_list`
--

CREATE TABLE `rate_list` (
  `id` int(11) NOT NULL,
  `rate` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rate_list`
--

INSERT INTO `rate_list` (`id`, `rate`) VALUES
(2, '12'),
(4, '17');

-- --------------------------------------------------------

--
-- Table structure for table `services_list`
--

CREATE TABLE `services_list` (
  `id` int(11) NOT NULL,
  `services` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services_list`
--

INSERT INTO `services_list` (`id`, `services`) VALUES
(1, 'Entertainment'),
(5, 'DJ'),
(6, 'Photography');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_portfolio`
--

CREATE TABLE `supplier_portfolio` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `portfolio_img` varchar(250) NOT NULL,
  `caption` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_portfolio`
--

INSERT INTO `supplier_portfolio` (`id`, `user_id`, `portfolio_img`, `caption`) VALUES
(1, 13, 'Jellyfish.jpg', 'aaaaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE `user_master` (
  `id` int(11) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `country` varchar(250) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `portfolio_image` varchar(255) NOT NULL,
  `cover_image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `other_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`id`, `first_name`, `last_name`, `email`, `password`, `country`, `user_type`, `portfolio_image`, `cover_image`, `description`, `other_description`) VALUES
(13, 'sumana barui', 'baruiiiiiiiiiiiiiiiiiiii', 'admin@gmail.com', '', 'India', 'Business', 'Koala.jpg', 'Koala.jpg', 'ggfgfg', 'aayjjumyijumy'),
(15, 'Baruiiiiiii', 'ss', 'ss@gmail.com', '', 'India', 'Client', 'Jellyfish.jpg', 'Jellyfish.jpg', 'b', 'aa'),
(24, 'sumana', 'barui', 'admin@gmail.com', '12', 'ab', 'Business', 'Jellyfish.jpg', 'Jellyfish.jpg', 'abc', 'aa'),
(25, 'Baruiiiiiii', 'Sumanaaaaa', 'admin@gmail.com', '12', 'rrr', 'Client', 'Jellyfish.jpg', 'Jellyfish.jpg', 'ggfgfg', 'aa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_master`
--
ALTER TABLE `admin_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_list`
--
ALTER TABLE `events_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_master`
--
ALTER TABLE `event_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback_master`
--
ALTER TABLE `feedback_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations_list`
--
ALTER TABLE `locations_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_master`
--
ALTER TABLE `project_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rate_list`
--
ALTER TABLE `rate_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services_list`
--
ALTER TABLE `services_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier_portfolio`
--
ALTER TABLE `supplier_portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_master`
--
ALTER TABLE `admin_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `events_list`
--
ALTER TABLE `events_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `event_master`
--
ALTER TABLE `event_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback_master`
--
ALTER TABLE `feedback_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `locations_list`
--
ALTER TABLE `locations_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `project_master`
--
ALTER TABLE `project_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rate_list`
--
ALTER TABLE `rate_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `services_list`
--
ALTER TABLE `services_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `supplier_portfolio`
--
ALTER TABLE `supplier_portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_master`
--
ALTER TABLE `user_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
