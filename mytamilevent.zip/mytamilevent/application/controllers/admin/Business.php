<?php
   if(!defined('BASEPATH')) exit('No direct script access allowed');
 
   class Business extends CI_Controller
   {

    public function __construct()
    {
      parent::__construct();
    }

    public function index()
    {
  	  $this->load->view('admin/inc/header');
  	  $this->load->view('admin/inc/sidebar');
      $this->load->view('admin/businesses');
  	  $this->load->view('admin/inc/footer');
    }

    public function add()
    {
  	  $this->load->view('admin/inc/header');
  	  $this->load->view('admin/inc/sidebar');
      $this->load->view('admin/addbusiness');
  	  $this->load->view('admin/inc/footer');
    }

   }
   ?>