  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Add</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>admin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">User Add</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
<?php foreach($users as $val) { ?>
<form action="<?php echo base_url();?>admin/dashboard/update/<?=$val->id;?>" method="post" enctype="multipart/form-data">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            
            <div class="card-body">
            
            <div class="row">
             <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleInputFile">Cover Image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" name="userfile" id="exampleInputFile">

                        <img src="<?php echo base_url('uploads/'.$val->cover_image);?>" border="0" width="90"> 
                      </div>
                    </div>
                  </div>
              </div>
              
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="exampleInputFile">Portfolio Image</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" name="userfile2" id="exampleInputFile">
                         <img src="<?php echo base_url('uploads/'.$val->portfolio_image);?>" border="0" width="90">      
                      </div>
                    </div>
                  </div>
              </div>
             </div>
             
             <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                    <label for="inputClientCompany">User Name</label>
                    <input type="text" id="inputClientCompany" name="user_name" class="form-control" value="<?=$val->username?>" required>
                  </div>
               </div>
               
               <div class="col-md-6">
                 <div class="form-group">
                    <label for="inputClientCompany">Display Name</label>
                    <input type="text" id="inputClientCompany" name="displayname" class="form-control" value="<?=$val->displayname?>"required>
                  </div>
               </div>
             </div>
             
             <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                    <label for="inputClientCompany">Password</label>
                    <input type="password" id="inputClientCompany" name="password" class="form-control" value="<?=$val->password?>" required>
                  </div>
               </div>
               
               <div class="col-md-6">
                 <div class="form-group">
                    <label for="inputClientCompany">Confirm Password</label>
                    <input type="password" id="inputClientCompany" name="p" class="form-control" value="<?=$val->password?>">
                  </div>
               </div>
             </div>
             
             <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                    <label for="inputClientCompany">Email</label>
                    <input type="email" id="inputClientCompany" name="email" class="form-control"value="<?=$val->email?>" required>
                  </div>
               </div>
               
               <div class="col-md-6">
                 <div class="form-group">
                    <label for="inputClientCompany">Phone</label>
                    <input type="text" id="inputClientCompany" name="phone" class="form-control" value="<?=$val->phone?>"required>
                  </div>
               </div>
             </div>
             
              <div class="row">
               <div class="col-md-6">
                  <div class="form-group">
                    <label for="inputClientCompany">Location</label>
                    <input type="text" id="inputClientCompany" name="location" class="form-control" value="<?=$val->location?>"required>
                  </div>
               </div>
               
               <div class="col-md-6">
                 <div class="form-group">
                    <label for="inputClientCompany">Website</label>
                    <input type="text" id="inputClientCompany" name="website" class="form-control" value="<?=$val->website?>">
                  </div>
               </div>
             </div>
              
              <div class="form-group">
                <label for="inputStatus">About</label>
                <textarea name="about" class="form-control"><?=$val->about?></textarea>
              </div>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        
      </div>
      <div class="row">
        <div class="col-12">
          <input type="submit" value="Create new User" class="btn btn-success float-right">&nbsp;
          <input type="button" value="Cancel" class="btn btn-danger">
        </div>
      </div>
</form>
<?php }?>
    </section>
  
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
