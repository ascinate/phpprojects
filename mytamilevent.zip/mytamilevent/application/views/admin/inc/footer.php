 <!-- Warning Section Starts -->
    <!-- Older IE warning message -->
    <!--[if lt IE 10]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade <br/>to any of the following web browsers to access this website.</p>
    <div class="iew-container">
        <ul class="iew-download">
            <li>
                <a href="http://www.google.com/chrome/">
                    <img src="../files/assets/images/browser/chrome.png" alt="Chrome">
                    <div>Chrome</div>
                </a>
            </li>
            <li>
                <a href="https://www.mozilla.org/en-US/firefox/new/">
                    <img src="../files/assets/images/browser/firefox.png" alt="Firefox">
                    <div>Firefox</div>
                </a>
            </li>
            <li>
                <a href="http://www.opera.com">
                    <img src="../files/assets/images/browser/opera.png" alt="Opera">
                    <div>Opera</div>
                </a>
            </li>
            <li>
                <a href="https://www.apple.com/safari/">
                    <img src="../files/assets/images/browser/safari.png" alt="Safari">
                    <div>Safari</div>
                </a>
            </li>
            <li>
                <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                    <img src="../files/assets/images/browser/ie.png" alt="">
                    <div>IE (9 & above)</div>
                </a>
            </li>
        </ul>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>
<![endif]-->
    <!-- Warning Section Ends -->
    <!-- Required Jquery -->
    <script data-cfasync="false" src="<?php echo base_url();?><?php echo base_url();?><?php echo base_url();?>cdn-cgi\scripts\5c5dd728\cloudflare-static\email-decode.min.js"></script><script type="text/javascript" src="<?php echo base_url();?>files\bower_components\jquery\js\jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\bower_components\jquery-ui\js\jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\bower_components\popper.js\js\popper.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\bower_components\bootstrap\js\bootstrap.min.js"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo base_url();?>files\bower_components\jquery-slimscroll\js\jquery.slimscroll.js"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo base_url();?>files\bower_components\modernizr\js\modernizr.js"></script>
    <!-- Chart js -->
    <script type="text/javascript" src="<?php echo base_url();?>files\bower_components\chart.js\js\Chart.js"></script>
    <!-- amchart js -->
    <script src="<?php echo base_url();?>files\assets\pages\widget\amchart\amcharts.js"></script>
    <script src="<?php echo base_url();?>files\assets\pages\widget\amchart\serial.js"></script>
    <script src="<?php echo base_url();?>files\assets\pages\widget\amchart\light.js"></script>
    <script src="<?php echo base_url();?>files\assets\js\jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\assets\js\SmoothScroll.js"></script>
    <script src="<?php echo base_url();?>files\assets\js\pcoded.min.js"></script>
    <!-- custom js -->
    <script src="<?php echo base_url();?>files\assets\js\vartical-layout.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\assets\pages\dashboard\custom-dashboard.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\assets\js\script.min.js"></script>

    <!-- data-table js -->
    <script src="<?php echo base_url();?>files\bower_components\datatables.net\js\jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url();?>files\bower_components\datatables.net-buttons\js\dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>files\assets\pages\data-table\js\jszip.min.js"></script>
    <script src="<?php echo base_url();?>files\assets\pages\data-table\js\pdfmake.min.js"></script>
    <script src="<?php echo base_url();?>files\assets\pages\data-table\js\vfs_fonts.js"></script>
    <script src="<?php echo base_url();?>files\bower_components\datatables.net-buttons\js\buttons.print.min.js"></script>
    <script src="<?php echo base_url();?>files\bower_components\datatables.net-buttons\js\buttons.html5.min.js"></script>
    <script src="<?php echo base_url();?>files\bower_components\datatables.net-bs4\js\dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url();?>files\bower_components\datatables.net-responsive\js\dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url();?>files\bower_components\datatables.net-responsive-bs4\js\responsive.bootstrap4.min.js"></script>

     <!-- Validation js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files\assets\pages\form-validation\validate.js"></script>

    <!-- Custom js -->
    <script src="<?php echo base_url();?>files\assets\pages\data-table\js\data-table-custom.js"></script>
</body>

</html>