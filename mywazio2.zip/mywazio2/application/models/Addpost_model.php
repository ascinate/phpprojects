<?php

	class Addpost_model extends CI_model
	{
       public function post_insert($data)
	   {
		  $query =$this->db->insert('post_master', $data);
	   }
	}

?>
