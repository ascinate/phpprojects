<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
 
   class Home extends CI_Controller
   {
	   
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->model('front_model');
    }
	
	public function index()
	{
  	   $this->load->view('includes/header');
  	   $this->load->view('home');
  	   $this->load->view('includes/footer');	
	}

    public function insert()
    {
	   $email = $this->input->post('email');
	   $pass = md5($this->input->post('password'));
	   $username = $this->input->post('name');
		  
	   $data = array( 'email'=>$email,
	 				  'password'=>$pass,
	 				  'displayname'=>$username );

	   $query = $this->db->get_where('user_master', array('email'=>$email));
	   $numrow = $query->num_rows();
       
       if($numrow==0)
       {
         $this->front_model->insert_user($data);
		 $lastid = $this->db->insert_id();
		 
		 if($lastid)
		 {
			  $res = $this->db->query("select * from `user_master` where `email` = '".$email."' 
		  						       and `password` = '".$pass."'");
			  $row = $res->row();
			  
			  $this->session->set_userdata('id',$row->id);
			  $this->session->set_userdata('email',$row->email);
			  $this->session->set_userdata('name',$row->displayname);
			  $this->session->set_userdata('profile_image',$row->portfolio_image);  

			  if($this->session->userdata('id')!="")
			  {
				  redirect('dashboard');
			  }
		 }
		 
       }
       
       else
       {
		  $this->session->set_flashdata('err', 'Email Already Exist!');
       	  redirect('/');
       }
	  	
	}

	 public function login_user()
	 { 
		  $email = $this->input->post('email');
		  $pass =  md5($this->input->post('password'));
		  
		  $res = $this->db->query("select * from `user_master` where `email` = '".$email."' and `password` = '".$pass."'");
		  $numrows = $res->num_rows();
		  
	  
		  if($numrows!=0)
		  {
			  $row = $res->row();
			  $this->session->set_userdata('id',$row->id);
			  $this->session->set_userdata('email',$row->email);
			  $this->session->set_userdata('name',$row->displayname);
			  $this->session->set_userdata('profile_image',$row->portfolio_image);   
		
			  if($this->session->userdata('id')!="")
			  {
				redirect('dashboard');
			  }
		  }
		  else
		  {
			  $this->session->set_flashdata('msg','Wrong email or password!');
			  redirect('/');
		  }
      }
        
	 public function user_logout()
	 {
	   $this->session->sess_destroy();
	   redirect('/');
	 }
   }

?>