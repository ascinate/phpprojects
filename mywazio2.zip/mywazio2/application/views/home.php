   <div class="top-sec">
     <div class="svg-sec">
        <img src="<?php echo base_url();?>assets/images/svg.PNG" alt="svg">
     </div>
     <div class="container">
      <div class="row">
         <div class="col-md-7">
            <div class="mobile-qwl">
              <div class="inside-qwl">
                  <div id="owl-demo4" class="owl-carousel owl-theme">
    
                      <div class="item">
                        <img src="<?php echo base_url();?>assets/images/slide-1.png" alt="pic1">
                      </div>
                      <div class="item">
                        <img src="<?php echo base_url();?>assets/images/slide-3.jpg" alt="pic1">
                      </div>
                      <div class="item">
                        <img src="<?php echo base_url();?>assets/images/slide-5.jpg" alt="pic1">
                      </div>
                      <div class="item">
                        <img src="<?php echo base_url();?>assets/images/slide-3.jpg" alt="pic1">
                      </div>
                  </div>
              </div>
            </div>
         </div>
         
         <div class="col-md-5">
            <div class="signup-login-sec">
               <a href="#" class="landing-logo"> <img src="<?php echo base_url();?>assets/images/logo.png" alt="logo"> </a>
               <div class="form-part-d1">
                 <p> Sign up to make money and interact with your fans!</p>
                 <div class="socal-media">
                    <ul>
                      <li>
                        <a href="#"> <i class="fab fa-twitter"></i> <span> Sign Up / Login with Twitter </span> </a>
                        <a href="#"> <i class="fab fa-facebook"></i> <span> Sign Up / Login with Facebook </span> </a>
                      </li>
                    </ul>
                 </div>
                 <p class="or-d1"> or </p>
                 <h6 class="prop">
                  <?php 
				    if($this->session->flashdata('err')) { echo $this->session->flashdata('err'); } 
					if($this->session->flashdata('msg')) { echo $this->session->flashdata('msg'); }
				   ?>
                </h6>

                <form action="<?php echo base_url();?>home/login_user" method="post" enctype="multipart/form-data">
                 <div id="login-d1" class="comon-div">
                    <div class="form-group">
                       <input type="email" placeholder="Email" class="form-control" name="email" required>
                    </div>
                    <div class="form-group">
                      <input type="password" placeholder="Password" class="form-control"  name="password" required>
                    </div>
                     <div class="logo-bn">
                        <input type="submit" name="submit" class="login-bn" value="Login">
                     </div>
                     <p> Don't have an account yet? </p>
                     <a class="sign-bn-text"  id="signup-bn"> Signup </a>
                 
                 </div>
               </form>

                 
              <form action="<?php echo base_url();?>home/insert" method="post" enctype="multipart/form-data">

                 <div id="signup-d1" class="comon-div">
                     <div class="form-group">
                       <input type="email" placeholder="Email" class="form-control" name="email" required>
                    </div>
                    <div class="form-group">
                       <input type="password" placeholder="Password" class="form-control" name="password" id="pw" required>
                       <span id="xv" style="padding-top: 10px; color: #FF0000;"></span>
                    </div>
                    <div class="form-group">
                       <input type="text" placeholder="Name" class="form-control" name="name" required>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2" required>
                        <label class="form-check-label" for="exampleRadios2">
                          By signing up you agree to our Terms of Service and Privacy Policy.
                        </label>
                      </div>
                    
                    <div class="logo-bn">
                        <input type="submit" name="submit" class="login-bn" value="Signup" id="sw"> 
                     </div>
                     <p> Do you have an account yet? </p>
                     <a class="login-bn-text"   id="login-bn"> Login </a>
                    
                 </div>
               </form>


                 <div class="more-information">
                    <h5> For more Information </h5>
                    <a href="#"> <img src="<?php echo base_url();?>assets/images/app-store.png" alt="logo"> </a> 
                    <a href="#"> <img src="<?php echo base_url();?>assets/images/google-play.png" alt="logo"> </a> 
                 </div>
                
               </div>
            </div>
         </div>
      </div>
     </div>
   </div>
 
   

