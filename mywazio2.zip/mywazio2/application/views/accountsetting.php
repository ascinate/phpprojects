<section class="body-d1">
   <div class="container">
       <div class="top-sec-d1">
          <p class="home"> Statements </p>
          <div id="serach-div" class="search-show-div">
            <div class="d-flex justify-content-between">
                <a href="#" id="close-search" class="serch-bn"> <i class="fas fa-times"></i> </a>
                <div class="form-group">
                    <input type="text" class="form-control">
                    <a href="#" class="serch-bn"> <i class="fas fa-search"></i> </a>
                 </div>
            </div>
            <p> POSTS </p>
          </div>
          <div class="seach-panel">
             <a href="#" id="serach-bn-d1" class="serch-bn"> <i class="fas fa-search"></i> </a>
          </div>
       </div>
       
       <div class="statements-sec-d1">
          <div class="container">
              <div class="row justify-content-between new-tabs-acount">
                  <div class="nav flex-column nav-pills left-td-menu" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active" data-toggle="pill" href="#demo-tab-d1" role="tab">
                    <span> <i class="far fa-user"></i> </span> Profile </a>
                    <a class="nav-link" data-toggle="pill" href="#demo-tab-d2" role="tab" >
                    <span> <i class="fas fa-at"></i> </span>  Account </a>
                    <a class="nav-link" data-toggle="pill" href="#demo-tab-d3" role="tab" >
                    <span> <i class="far fa-bell"></i> </span>  Notifications  </a>
                    <a class="nav-link"  data-toggle="pill" href="#demo-tab-d4" role="tab" >
                    <span> <i class="fas fa-fingerprint"></i> </span>  Security  </a>
                    <a class="nav-link" data-toggle="pill" href="#demo-tab-d5" role="tab"> 
                    <span> <i class="fas fa-magic"></i> </span> What's New </a>
                  </div>
                  
                  <div class="tab-content right-dl-td" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="demo-tab-d1" role="tabpanel" >
                       <div class="total-profile">
                          <div class="comon-header-ac">
                             <h3> EDIT PROFILE &nbsp;&nbsp;</h3>
                             <p> CHANGE PROFILE AND COVER PHOTOS </p>
                          </div>
                          <?php foreach($users as $val) { ?>
                           <form action="<?php echo base_url();?>accountsetting/update/<?=$val->id;?>" method="post" enctype="multipart/form-data">
                          
                              <div class="img-sec-d1">
                                 <div class="comver-sec">
                                    <div class="yes">
                                      <span class="btn_upload">
                                        <input type="file" id="imag" title="" name="coverImage" class="input-img"/>
                                        Upload Cover Photo
                                      </span>
                                      
                                      <?php if($val->cover_image!="") { ?>
                                      <img src="<?php echo base_url();?>uploads/<?=$val->cover_image?>" alt="pic3" class="preview1" id="a1">
                                      <?php } else {?>
                                      <img src="<?php echo base_url();?>assets/images/post-d1.jpg" alt="pic3" class="preview1" id="a2">
                                      <?php }?>
                                      
                                      <img id="myimg" border="0" src="#" style="display: none;" class="preview1"/>
                                      
                                      <input type="button" id="removeImage1" value="&#10005;" class="btn-rmv1" />
                                    </div>
                                 </div>
                                 <div class="profile-sec-d1">
                                    <div class="yes">
                                      <span class="btn_upload">
                                        <input type="file" id="imag2" title="" name="profileImage" class="input-img"/>
                                        Upload Profile Photo
                                        </span>
                                         
                                      <?php if($val->portfolio_image!="") { ?>
                                      <img src="<?php echo base_url();?>uploads/<?=$val->portfolio_image?>" alt="pic3" class="preview2" id="p1">
                                      <?php } else {?>
                                      <img src="<?php echo base_url();?>assets/images/avatar.png" alt="pic3" class="preview2" id="p2">
                                      <?php }?>
                                     
                                       <img id="proimg" border="0" src="#" style="display: none;" class="preview2"/> 
                                       
                                      <input type="button" id="removeImage2" value="&#10005;" class="btn-rmv2" />
                                    </div>
                                 </div>
                              </div>
                       
                          <p class="profile-text"> Profile images must not contain nudity or explicit material. </p>
                          
                          
                          <div class="profile-form">
                             <div class="form-group">
                                <label> USERNAME <span> (optional) </span> </label>
                                <div class="user-flid">
                                   <input type="text" class="form-control" placeholder="" name="user_name" value="<?=$val->username;?>">
                                   <span> <i class="fas fa-check"></i></span>
                                </div>
                             </div>
                             <div class="form-group">
                                <label> DISPLAY NAME <span> (optional) </span> </label>
                                <div class="user-flid">
                                   <input type="text" class="form-control" placeholder="" name="displayname" value="<?=$val->displayname;?>">
                                </div>

                             </div>
                             
                             <div class="form-group">
                                <label> LOCATION <span> (optional) </span> </label>
                                <div class="user-flid">
                                   <input type="text" class="form-control" placeholder="" name="location" value="<?=$val->location;?>">
                                </div>
                                
                             </div>
                             <div class="form-group">
                                <label> WEBSITE URL <span> (optional) </span> </label>
                                <div class="user-flid">
                                   <input type="text" class="form-control" placeholder="" name="website" value="<?=$val->website;?>">
                                </div>
                                
                             </div>
                             
                             <input type="submit" name="submit" class="prifile-save-bn" value="Save changes"> 
                            </form>
                           <?php }?>
                             <div class="clearfix"></div>
                             
                          </div>
                       </div>
                    
                    </div>
                    <div class="tab-pane fade" id="demo-tab-d2" role="tabpanel">
                       <div class="account-sec">
                          <div class="spotify-sec">
                            <h4> TWITTER ACCOUNT </h4>
                            <a href="#" class="con-bn">  Connect </a>
                          </div>
                          <div class="spotify-sec">
                            <h4> GOOGLE ACCOUNT </h4>
                            <a href="#" class="con-bn">  Connect </a>
                          </div>
                          <h4> Account Info</h4>
                          <div class="form-group">
                            <label> USERNAME <span> (optional) </span> </label>
                            <div class="user-flid">
                               <input type="text" class="form-control" placeholder="u72039274">
                               <span> <i class="fas fa-check"></i></span>
                            </div>
                            <p class="profile-text"> https://onlyfans.com/u72039274 </p>
                         </div>
                          <div class="clearfix"></div>
                           <button class="prifile-save-bn"> Save changes </button>
                           <div class="clearfix"></div>
                            <div class="form-group">
                                <label> E-MAIL <span> (optional) </span> </label>
                                <div class="user-flid">
                                   <input type="text" class="form-control" placeholder="email@gmail.com">
                                </div>
                                <p class="profile-text"> E-mail subrata.das23@yahoo.com is verified </p>
                             </div>
                           <div class="clearfix"></div>
                           <button class="prifile-save-bn"> changes Email </button>
                           <div class="clearfix"></div>
                            <h4 class="mt-3"> ONLYFANS ACCOUNTS </h4>
                           <div class="form-group">
                                <label> CONNECT ANOTHER ONLYFANS ACCOUNT </label>
                                <div class="user-flid">
                                   <input type="text" class="form-control required" 
                                   placeholder="Enter another OnlyFans account username">
                                </div>
                             </div>
                          <button type="button" class="toggle-disabled" disabled>  Connect </button>
                          
                          <div class="bottom-acdion">
                             <div id="accordion" role="tablist" aria-multiselectable="true">

                              <!-- Accordion Item 1 -->
                                <div class="card">
                                  <div class="card-header" role="tab" id="accordionHeadingOne">
                                    <div class="mb-0 row">
                                      <div class="col-12 no-padding accordion-head">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#accordionBodyOne" aria-expanded="false" aria-controls="accordionBodyOne"
                                          class="collapsed ">
                                          <i class="fas fa-chevron-down" aria-hidden="true"></i>
                                          <h3> LOGIN SESSIONS </h3>
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                      
                                  <div id="accordionBodyOne" class="collapse" role="tabpanel" aria-labelledby="accordionHeadingOne" aria-expanded="false" data-parent="accordion">
                                    <div class="card-block col-12">
                                        <div class="text-part">
                                           <h5> Chrome 85.0, Windows 7 <span> 103.75.161.75 - India </span> </h5>
                                           <p> Online </p>
                                        </div> 
                                        <a href="#" class="con-bn nex-bn">  Connect </a>                      
                                    </div>
                                  </div>
                                </div>

                              <!-- Accordion Item 2 -->
                                <div class="card">
                                  <div class="card-header" role="tab" id="accordionHeadingTwo">
                                    <div class="mb-0 row">
                                      <div class="col-12 no-padding accordion-head">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#accordionBodyTwo" aria-expanded="false" aria-controls="accordionBodyTwo"
                                          class="collapsed ">
                                          <i class="fa fa-angle-down" aria-hidden="true"></i>
                                          <h3>PASSWORDPASSWORD </h3>
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                      
                                  <div id="accordionBodyTwo" class="collapse" role="tabpanel" aria-labelledby="accordionHeadingTwo" aria-expanded="false" data-parent="accordion">
                                    <div class="card-block col-12">
                                       <div class="comon-div-cpl">
                                          <div class="form-group comon-flid">
                                             <label> NEW PASSWORD </label>
                                             <input type="text" class="form-control">
                                          </div>
                                          <div class="form-group comon-flid">
                                             <label> CONFIRM NEW PASSWORD </label>
                                             <input type="text" class="form-control">
                                          </div>
                                        </div>
                                    </div>
                                  </div>
                                </div>

                              <!-- Accordion Item 3 -->
                              <div class="card">
                                <div class="card-header" role="tab" id="accordionHeadingThree">
                                  <div class="mb-0 row">
                                    <div class="col-12 no-padding accordion-head">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#accordionBodyThree" aria-expanded="false" aria-controls="accordionBodyThree"
                                        class="collapsed ">
                                        <i class="fa fa-angle-down" aria-hidden="true"></i>
                                        <h3>DELETE ACCOUNT</h3>
                                      </a>
                                    </div>
                                  </div>
                                </div>
                    
                                <div id="accordionBodyThree" class="collapse" role="tabpanel" aria-labelledby="accordionHeadingThree" aria-expanded="false" data-parent="accordion">
                                  <div class="card-block col-12">
                                     <div class="comon-sec-dl">
                                        
                                            <div class="form-group">
                                                <label> CODE </label>
                                                <div class="user-flid patch-d2">
                                                  <img src="images/default.png">
                                                   <input type="text" class="form-control required-d1" 
                                                   placeholder="Enter another OnlyFans account username">
                                                </div>
                                                <button type="button" class="toggle-disabled-d1" disabled>  Connect </button>
                                                <p class="comon-sec-f"> This will permanently delete your account </p>
                                             </div>
                                        
                                        
                                     </div>
                                  </div>
                                </div>
                              </div>
                    
                    
                            </div>
                          </div>
                           
                       </div>
                    </div>
                    <div class="tab-pane fade" id="demo-tab-d3" role="tabpanel" >
                        <div class="comon-notis-d1">
                            
                            
                             <div class="toggle comon-sw" id="con-bn-dl">
                                <p> PUSH NOTIFICATIONS </p>
                                <div class="toggle-label toggle-label-off"></div>
                                <div class="toggle-switch"></div>
                                <div class="toggle-label toggle-label-on"></div>
                              </div>
                            
                            <div id="plush-noti-d1" class="comon-noti-d2">
                                <h4> RECEIVE WEBPUSH ABOUT </h4>
                                <div class="details-part-d1">
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Campaign Contribution
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                   
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New comment
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Likes
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Stream
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Subscriber
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Tip
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> Important Direct Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                </div>
                            </div>
                            
                            <div class="toggle2 comon-sw" id="con-bn-d2">
                                <p> EMAIL NOTIFICATIONS </p>
                                <div class="toggle-label toggle-label-off"></div>
                                <div class="toggle-switch"></div>
                                <div class="toggle-label toggle-label-on"></div>
                              </div>
                            
                            
                            
                            <div id="email-dl-d1" class="comon-sec-trun">
                                
                                 <div class="toggle3 comon-sw" id="con-bn-d2">
                                    <p> SHOW FULL TEXT OF THE MESSAGE IN THE NOTIFICATION EMAIL </p>
                                    <div class="toggle-label toggle-label-off"></div>
                                    <div class="toggle-switch"></div>
                                    <div class="toggle-label toggle-label-on"></div>
                                  </div>
                                  
                                  <div class="toggle4 comon-sw" id="con-bn-d2">
                                    <p> MONTHLY NEWSLETTER </p>
                                    <div class="toggle-label toggle-label-off"></div>
                                    <div class="toggle-switch"></div>
                                    <div class="toggle-label toggle-label-on"></div>
                                  </div>
                                  
                                  <div class="toggle4 comon-sw" id="con-bn-d2">
                                    <p> MONTHLY NEWSLETTER </p>
                                    <div class="toggle-label toggle-label-off"></div>
                                    <div class="toggle-switch"></div>
                                    <div class="toggle-label toggle-label-on"></div>
                                  </div>
                                
                            </div>
                            
                            <div class="comon-noti-d2" style="display: block;">
                                <h4> RECEIVE WEBPUSH ABOUT </h4>
                                <div class="details-part-d1">
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Campaign Contribution
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                   
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New comment
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Likes
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Stream
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Subscriber
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Tip
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> Important Direct Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked="">
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                </div>
                            </div>
                            
                            <div class="box-select-part">
                                <div class="form-group">
                                    <label> NEW LIKES SUMMARY </label>
                                    <select class="form-control">
                                       <option> Disabled </option>
                                       <option> Every Hour </option>
                                       <option> Every 3 Hours </option>
                                       <option> Every 6 Hours </option>
                                       <option> Every 24 Hours </option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="box-select-part">
                                <div class="form-group">
                                    <label> NEW POSTS SUMMARY </label>
                                    <select class="form-control">
                                       <option> Disabled </option>
                                       <option> Every Hour </option>
                                       <option> Every 3 Hours </option>
                                       <option> Every 6 Hours </option>
                                       <option> Every 24 Hours </option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="box-select-part">
                                <div class="form-group">
                                    <label> NEW PRIVATE MESSAGE SUMMARY </label>
                                    <select class="form-control">
                                       <option> Disabled </option>
                                       <option> Every Hour </option>
                                       <option> Every 3 Hours </option>
                                       <option> Every 6 Hours </option>
                                       <option> Every 24 Hours </option>
                                    </select>
                                </div>
                                
                                <div class="form-check check-box">
                                  <label class="container-d1"> <span class="dem-text"> Receive less notifications
                                   </span>
                                    <input type="checkbox" onclick="myGeeks()">
                                    <span class="checkmark"></span>
                                  </label>
                                </div>
                            </div>
                            
                            <div class="comon-div-text">
                               <h5> TELEGRAM BOT <span> Please do not share this link with anyone </span> </h5>
                               <div class="w-25"> <a href="#" class="con-bn float-right mt-3 text-uppercase"> 
                                Get link </a> </div>
                            </div>
                            <h5 class="comon-sub"> SITE NOTIFICATIONS </h5>
                            
                            <div class="comon-noti-d2">
                                <h4> RECEIVE WEBPUSH ABOUT </h4>
                                <div class="details-part-d1">
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Campaign Contribution
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                   
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New comment
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Likes
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Stream
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Subscriber
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Tip
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> Important Direct Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                </div>
                            </div>
                            
                            <h5 class="comon-sub"> TOAST NOTIFICATIONS</h5>
                            
                            <div class="comon-noti-d2">
                                <h4> RECEIVE WEBPUSH ABOUT </h4>
                                <div class="details-part-d1">
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Campaign Contribution
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                   
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New comment
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Likes
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                   <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Stream
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Subscriber
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Tip
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> Important Direct Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                    <div class="form-check check-box">
                                      <label class="container-d1"> <span class="dem-text"> New Messages
                                       </span>
                                        <input type="checkbox" onclick="myGeeks()" checked>
                                        <span class="checkmark"></span>
                                      </label>
                                    </div>
                                    
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="tab-pane fade" id="demo-tab-d4" role="tabpanel" >
                         
                         <div class="sequrity-part" id="special-div-sq">
                            <h4> TWO STEP VERIFICATION </h4>
                            <div class="toggle5 comon-sw" id="copon-d1" data-toggle="modal" data-target="#copon">
                              <p> GOOGLE AUTHENTICATOR </p>
                              <div class="toggle-label toggle-label-off"></div>
                              <div class="toggle-switch"></div>
                              <div class="toggle-label toggle-label-on"></div>
                            </div>
                            
                            <div id="open-di-copon">
                              <p> Authenticator App setup </p>
                            </div>
                            
                            <h4> PROFILE PRIVACY </h4>
                            
                            <div class="toggle6 comon-sw">
                              <p> SHOW ACTIVITY STATUS </p>
                              <div class="toggle-label toggle-label-off"></div>
                              <div class="toggle-switch"></div>
                              <div class="toggle-label toggle-label-on"></div>
                            </div>
                            
                            <div class="toggle7 comon-sw">
                              <p> SHOW SUBSCRIPTION OFFERS </p>
                              <div class="toggle-label toggle-label-off"></div>
                              <div class="toggle-switch"></div>
                              <div class="toggle-label toggle-label-on"></div>
                            </div>
                            
                            <h2> ALLOW CO-STREAMING REQUESTS </h2>
                            
                            <div class="raid-bn-show">
                               <div class="custom-control custom-radio custom-control-inline">
                                  <input type="radio" id="customRadioInline1" 
                                  name="customRadioInline1" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadioInline1">
                                  Nobody </label>
                                </div>
                                <div class="custom-control custom-radio custom-control-inline">
                                  <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadioInline2">
                                  Mutual friends </label>
                                </div>
                                
                                <div class="custom-control custom-radio custom-control-inline">
                                  <input type="radio" id="customRadioInline3" name="customRadioInline1" class="custom-control-input">
                                  <label class="custom-control-label" for="customRadioInline3">
                                  Subscribers </label>
                                </div>
                            </div>
                            
                         </div>
                         
                        
                    </div>
                    <div class="tab-pane fade" id="demo-tab-d5" role="tabpanel" >
                       <div class="whats-new">
                          <h3> WHAT'S NEW </h3>
                          <div class="comon-news">
                             <h4> APRIL </h4>
                             <h5> Apr 4, 2020 </h5> 
                             <p> Creators now have an option to congratulate their Top Fans from the previous month. Top Fans are calculated from overall support of the Creator during the month. </p>
                          </div>
                          <div class="comon-news">
                             <h4> FEBRUARY </h4>
                             <h5> Feb 4, 2020 </h5> 
                             <p> Creators now have an option to congratulate their Top Fans from the previous month. Top Fans are calculated from overall support of the Creator during the month. </p>
                          </div>
                          <div class="comon-news">
                             <h4> DECEMBER </h4>
                             <h5> Dec 29, 2019 </h5> 
                             <p> Creators now have an option to congratulate their Top Fans from the previous month. Top Fans are calculated from overall support of the Creator during the month. </p>
                             
                             <h5> Dec 29, 2019 </h5> 
                             <p> Creators now have an option to congratulate their Top Fans from the previous month. Top Fans are calculated from overall support of the Creator during the month. </p>
                          </div>
                       </div>
                    </div>
                  </div>
              </div>
          </div>
          
       </div>
   </div>
</section>   

