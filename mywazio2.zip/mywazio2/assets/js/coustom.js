// JavaScript Document

$(document).ready(function () {

	var owl = $("#owl-demo4");
	owl.owlCarousel({
		items: 1, //10 items above 1000px browser width
		itemsMobile: false, // itemsMobile disabled - inherit from itemsTablet option
		navigation: true,
		dots: false,
		autoplay: true,
		nav: false,
		autoplayTimeout: 2000,
		autoplayHoverPause: true,
		lazyLoad: true,
		loop: true,
		responsive: {
			0: {
				items: 1
			},
			600: {
				items: 1
			},
			1000: {
				items: 1
			}
		}

	});

});

$(document).ready(function () {

	var owl = $("#owl-demo2");
	owl.owlCarousel({
		items: 1, //10 items above 1000px browser width
		itemsMobile: false, // itemsMobile disabled - inherit from itemsTablet option
		navigation: true,
		dots: true,
		autoplay: false,
		nav: true,
		lazyLoad: true,
		loop: true,
		responsive: {
			0: {
				items: 1
			},
			600: {
				items: 1
			},
			1000: {
				items: 1
			}
		}

	});

});

$(document).ready(function(){
  $("#signup-bn").click(function(){
	$("#login-d1").hide();
	$("#signup-d1").show();
  });
  $("#login-bn").click(function(){
    $("#signup-d1").hide();
	$("#login-d1").show();
  });
});

//$(document).ready(function() {
//	$('#slid-menu-d1').click(function() {
//		$('#new-more .total-sec').addClass('color-change-div');
//    });
//});
//$(document).ready(function() {
//	$('#close-menu').click(function() {
//		$('#new-more .total-sec').removeClass('color-change-div');
//    });
//});
//$(document).ready(function() {
//	$('.nav-link').click(function() {
//		$('#new-more .total-sec').removeClass('color-change-div');
//    });
//});
$(document).ready(function(){
 $("#slid-menu-d1").click(function(){
	$(".total-show-div").toggle();
  });
});
$(document).ready(function(){
 $("#close-menu").click(function(){
	$(".total-show-div").hide();
  });
});
$(document).ready(function(){
 $(".nav-link").click(function(){
	$(".total-show-div").hide();
  });
});


$(document).ready(function() {
    $('#example').DataTable();
} );


$(document).ready(function() {
	$('#slid-menu-d1').click(function() {
		$('#slide-menu .sidenav').toggleClass('show-menu-d1');
	  });
});

$(document).ready(function() {
	$('#slid-menu-d1').click(function() {
		$('body').toggleClass('hide-off');
	  });
});

$(document).ready(function() {
	$('#close-menu').click(function() {
		$('#slide-menu .sidenav').removeClass('show-menu-d1');
	  });
});

$(document).ready(function() {
	$('#close-menu').click(function() {
		$('body').removeClass('hide-off');
	  });
});
$(document).ready(function() {
	$('.nav-link').click(function() {
		$('body').removeClass('hide-off');
	  });
});

$(document).ready(function() {
	$('.nav-link').click(function() {
		$('#slide-menu .sidenav').removeClass('show-menu-d1');
	  });
});

$(document).ready(function() {
    $('.total-show-div').click( function() {
       $('#slide-menu .sidenav').removeClass('show-menu-d1');
    });
	$('.total-show-div').click( function() {
       $(".total-show-div").hide();
    });
});

$(document).ready(function() {
  $( ".like-bn" ).click(function() {
	$( this ).toggleClass( "highlight" );
  });
});
$(document).ready(function() {
  $( ".like-bn" ).click(function() {
	$("#like-div").toggle();
  });
});
$(document).ready(function() {
  $( "#coment-show" ).click(function() {
	$("#show-comment-part").toggle();
  });
});
$(document).ready(function() {
  $( "#coment-show" ).click(function() {
	$("#emoj-div-show").hide();
	$("#gif-box").hide();
  });
});
$(document).ready(function() {
  $( "#gif-bn" ).click(function() {
	$("#gif-box").toggle();
	$("#emoj-div-show").hide();
  });
});
$(document).ready(function() {
  $( "#emojj-bn" ).click(function() {
	$("#emoj-div-show").toggle();
	$("#gif-box").hide();
  });
});

$(document).ready(function() {
  $( "#serach-bn-d1" ).click(function() {
	$("#serach-div").show();
  });
});
$(document).ready(function() {
  $( "#close-search" ).click(function() {
	$("#serach-div").hide();
  });
});


$('#btn-u').click(function(){
    $(this).find('i').toggleClass('fas fa-close fas fa-chevron-down');
});

$(document).ready(function() {
  $( "#con-bn-dl" ).click(function() {
	$("#plush-noti-d1").toggle();
  });
});

$(document).ready(function() {
  $( "#con-bn-d2" ).click(function() {
	$("#email-dl-d1").toggle();
  });
});


$(document).ready(function() {
  $( "#copon-d1" ).click(function() {
	$("#open-di-copon").toggle();
  });
});


