<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
 
   class Accountsetting extends CI_Controller
   {

    public function __construct()
    {
      parent::__construct();
      $this->load->database();
      $this->load->helper('url');
      $this->load->library('session');
      $this->load->model('accountsetting_model');
    }
	
	public function index()
    {
      $id=$this->session->userdata('id');

      $data['users'] = $this->accountsetting_model->get_fan_list($id);

       $this->load->view('includes/header');
       $this->load->view('includes/header_top');
       $this->load->view('accountsetting',$data);
       $this->load->view('includes/footer');
    }

    public function update()
    {
        $id = $this->session->userdata('id');
		$rec = $this->db->get_where('user_master',array('id'=>$id))->row();
        
		if($_FILES['coverImage']['name'])
		{
			$photo = time()."_".$_FILES['coverImage']['name'];
			$photo_tmp=$_FILES['coverImage']['tmp_name'];
			
			$dir='uploads';
			
			move_uploaded_file($photo_tmp, $dir."/".$photo);
        }
		
		else
		{
			$photo = $rec->cover_image;
		}
        
		if($_FILES['profileImage']['name'])
		{
			$photo2= time()."_".$_FILES['profileImage']['name'];
			$photo_tmp2=$_FILES['profileImage']['tmp_name'];
			$dir='uploads';
			
			  move_uploaded_file($photo_tmp2, $dir."/".$photo2);
        }
		
		else
		{
			$photo2 = $rec->portfolio_image;
		}

        $data = array( 'username'=>$this->input->post('user_name'),
						'displayname'=>$this->input->post('displayname'),
						'location'=>$this->input->post('location'),
						'website'=>$this->input->post('website'),
						'cover_image'=>$photo,
						'portfolio_image'=>$photo2 );

        $result = $this->accountsetting_model->update($id,$data);
		redirect('accountsetting');
		/*echo $this->db->last_query();
		
		if($result)
		{
		    $this->session->set_flashdata('success', 'Profile updated successfully!');
         	redirect('accountsetting');
		}*/
    }
	
	public function coverpic()
	{
	   if(is_uploaded_file($_FILES['coverImage']['tmp_name'])) 
	   {
		$sourcePath = $_FILES['coverImage']['tmp_name'];
		$targetPath = "uploads/".$_FILES['coverImage']['name'];
		
			if(move_uploaded_file($sourcePath,$targetPath)) 
			{
			?>
			<img class="image-preview" src="<?php echo $targetPath; ?>" class="upload-preview" />
			<?php
			}
	   }
    }


}
?>