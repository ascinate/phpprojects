<?php
	class Font_model extends CI_model
	{
	  public function insert_user($data){
	  $query =$this->db->insert('user_master',$data);
	  }
	
	 public function login()
	   {
		  $email = $this->input->post('email');
		  $pass = $this->input->post('password');
		  
		  $this->db->select('*');
		  $this->db->from('user_master');
		  $this->db->where('email',$email);
		  $this->db->where('password',$pass);
	  
		  if($query=$this->db->get())
		  {
			 return $query->result_array();
		  }

		  else
		  {
			return false;
		  }
		 
		}
	}
?>