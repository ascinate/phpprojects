
  <div id="new-more">
    <div class="total-sec">
          
         
        <section class="body-d1">
           <div class="container">
               <div class="top-sec-d1">
                  <p class="home"> fanlisting </p>
                  <div id="serach-div" class="search-show-div">
                    <div class="d-flex justify-content-between">
                        <a href="#" id="close-search" class="serch-bn"> <i class="fas fa-times"></i> </a>
                        <div class="form-group">
                            <input type="text" class="form-control">
                            <a href="#" class="serch-bn"> <i class="fas fa-search"></i> </a>
                         </div>
                    </div>
                    <p> POSTS </p>
                  </div>
                  <div class="seach-panel">
                     <a href="#" id="serach-bn-d1" class="serch-bn"> <i class="fas fa-search"></i> </a>
                  </div>
               </div>
               
               <div class="listing-sec-d1">
                  
                  
                  <div class="listing-div" id="jar">
                      <div class="row">

                      <?php foreach($users as $val) { 
                        
                        ?>
                         <div class="col-md-3 content">
                            <div class="listing-part-inside">
                               <div class="listing-img">
                                <img src="<?=base_url()?>uploads/<?=$val->cover_image?>" >
                               </div>
                               <div class="listing-text">
                                  <div class="listing-user-pic">
                                     <img src="<?=base_url()?>uploads/<?=$val->portfolio_image?>" >                                 
                                      </div>
                                  <div class="user-details-listing">
                                     <h2> <?=$val->username?> </h2>
                                     <p> <?=$val->email?></p>
                                     <ul class="user-list-option">
                                       <li> <span class="comon-sec"> Subscription </span>: <span> $13.99 </span> </li>
                                       <li> <span class="comon-sec"> Date </span>: <span> 04/09/2020 - 05/09/2020 </span></li>
                                       <li> <span class="comon-sec"> Auto renewal </span>: 
                                          <div class="onoffswitch">
                                            <input type="checkbox" name="onoffswitch" 
                                            class="onoffswitch-checkbox" id="myonoffswitch" checked>
                                            <label class="onoffswitch-label" for="myonoffswitch">
                                              <span class="onoffswitch-inner"></span>
                                              <span class="onoffswitch-switch"></span>
                                            </label>
                                          </div>
                                       </li>
                                     </ul>
                                     
                                     <a href="#" class="sub-bn"> <span> <i class="fas fa-lock-open"></i> </span> 
                                     Cancel Subscription </a>
                                  </div>
                               </div>
                            </div>
                         </div>
                       <?php }?>

                         
                   </div>
                  
                  </div>
                  <nav>
                    <ul class="pagination justify-content-center pagination-sm">
                    </ul>
                  </nav>
                  
               </div>
           </div>
        </section>   
        
      