<section class="body-d1 st-body post-div">
    <div class="container">
    <form id="myform">
        <div class="top-sec-d1">
           <p> <span> <i class="fas fa-arrow-left"></i> </span> NEW POST </p>
           
           <div class="right-sec-post">
               <div class="form-group">
                   <div class="user-flid">
                      
                   </div>
                   <button type="button" class="toggle-disabled" disabled>  Post </button>
                </div>
               
           </div>
        </div>
        <div class="show-add-row" id="add-row-div">
           <a href="#" id="close-div-add" class="close-bn-div"> <i class="fas fa-times-circle"></i> </a>
           <div class="table-responsive">
               <table id="test-table" class="table table-condensed">
                 
                 <tbody id="test-body">
                   <tr id="row0">
                     <td>
                      <div class="row-div-sec">
                         <input name='from_value0' value='' type='text' class='form-control' />
                         <button class='delete-row comon-bg-bn' type='button' >  </button>
                      </div> 
                       
                     </td>
                   </tr>
                   <tr id="row0">
                     <td>
                      <div class="row-div-sec">
                         <input name='from_value0' value='' type='text' class='form-control' />
                         <button class='delete-row comon-bg-bn' type='button' >  </button>
                      </div> 
                       
                     </td>
                   </tr>
                 </tbody>
               </table>
           </div>
           <input id='add-row' class='btn btn-primary ad-bn-sec-1' type='button' value='+ Add another option' />
        </div>
        <div class="img-box-show-d1">
           
               <div class="img-sec-d1">
                  <div class="comver-sec">
                     <div class="yes">
                       <img id="ImgPreview-post" src="<?php echo base_url();?>assets/images/pic-d1.jpg" class="preview1" />
                       <input type="button" id="removeImage1-post" value="&#10005;" class="btn-rmv1" />
                     </div>
                  </div>
                  
               </div>
        </div>
        <div class="text-area">
           <div class="form-group">
              <textarea name="" cols="" rows="" class="form-control required-post" placeholder="Enter another OnlyFans account username"></textarea>
           </div>
        </div>
        
        <div class="post-out-put-sec">
           <span class="btn_upload">
                         
           <input type="file" id="imag-post" title="" class="input-img"/>
            <i class="far fa-image"></i>
           </span>
           <a href="#" id="add-bn-show-d1"> <i class="fas fa-outdent"></i> </a>
        </div>
    </form>
        
        
    </div>
 </section> 