<?php
   $result = $this->db->get_where('user_master', array('id' => $this->session->userdata('id')))->row();
?>
<section class="body-d1">
<div class="container">
   <div class="top-sec-d1">
      <p class="home"> Dashboard </p>
      <div id="serach-div" class="search-show-div">
        <div class="d-flex justify-content-between">
            <a href="#" id="close-search" class="serch-bn"> <i class="fas fa-times"></i> </a>
            <div class="form-group">
                <input type="text" class="form-control">
                <a href="#" class="serch-bn"> <i class="fas fa-search"></i> </a>
             </div>
        </div>
        <p> POSTS </p>
      </div>
      <div class="seach-panel">
         <a href="#" id="serach-bn-d1" class="serch-bn"> <i class="fas fa-search"></i> </a>
      </div>
   </div>
   
   <div class="next-sec-d1">
      <div class="col-md-8 pl-0">
         <div class="comon-box-d1 sp-width">
             <div class="user-details">
                <div class="profile-d1">
                   <figure>
                     <?php if($result->portfolio_image!="") { ?>
					  <img src="<?php echo base_url();?>uploads/<?=$result->portfolio_image?>" alt="pic3">
					  <?php } else {?>
					  <img src="<?php echo base_url();?>assets/images/avatar.png" alt="pic3" width="">
					  <?php }?>
                   </figure>
                    <p> <?php echo $result->displayname;?>
                    <span> <?php echo $result->email;?></span>
                    </p>
                </div>
                
                <div class="right-dots">
                  <p>Yesterday</p>
                    <div class="dropdown">
                        <button class="new-dp-d1 dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-ellipsis-h"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                          <a class="dropdown-item" href="#">Copy link to post</a>
                          <a class="dropdown-item" href="#">Pin to your profile page</a>
                          <a class="dropdown-item" href="#">Edit post</a>
                          <a class="dropdown-item" data-toggle="modal" data-target=".bd-example-modal-sm">
                          Delete post</a>
                        </div>
                      </div>
                </div>
             </div>
             <div class="post-sec">
                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.  </p>
                <div class="img-box">
                  <img src="<?php echo base_url();?>assets/images/blog-pic1.jpg" alt="pic">
                </div>
             </div>
             <div class="commennt-sec">
                <ul>
                  <li> <a class="like-bn"> <i class="fas fa-heart"></i> </a> </li>
                  <li> <a id="coment-show"> <span class="flaticon-messenger"></span> </a> </li>
                  <li> 
                    <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fcodepen.io%2Fsunnysingh%2Fpen%2FOPxbgq" class="facebook share-comon-bn"> <i class="fab fa-facebook-f"></i>
                    <span>Facebook </span> </a> 
                  </li>
                  <li> 
                    <a  href="https://twitter.com/share?url=http%3A%2F%2Fcodepen.io%2Fsunnysingh%2Fpen%2FOPxbgq&text=Share Buttons Demo&via=sunnyismoi" class="twiiter share-comon-bn"> <i class="fab fa-twitter"></i>
                    <span>twitter </span> </a> 
                  </li>
                  <li> 
                    <a href="#" class="instagram share-comon-bn"> <i class="fab fa-instagram"></i>
                    <span>instagram </span> </a> 
                  </li>
                  <li> <a href="#"> <span class="flaticon-bookmark"></span> </a> </li>
                  
                </ul>
             </div>
             <div id="like-div" class="one-like"> <p> 1 Like </p> </div>
             <div id="show-comment-part" class="show-comments">
                <div class="top-comment-d1">
                  <a  id="gif-bn" class="gif"> [GIF] </a>
                  <a  id="emojj-bn" class="emojj"> <i class="far fa-smile"></i> </a>
                </div>
                <div id="gif-box" class="gif-div-show">
                  <div class="row">
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                      <a href="#"> 
                         <div class="box-gif">
                            <img src="<?php echo base_url();?>assets/images/animated-flower-image-0050.gif" alt="pico">
                         </div>
                      </a>
                   </div>
                </div>
                <div id="emoj-div-show" class="emji-sec">
                   <div class="row">
                     <a href="#"> <i class="fas fa-smile-wink"></i> </a>
                     <a href="#"> <i class="fas fa-surprise"></i> </a>
                     <a href="#"> <i class="fas fa-smile-wink"></i> </a>
                     <a href="#"> <i class="fas fa-smile-beam"></i> </a>
                     <a href="#"> <i class="fas fa-sad-cry"></i> </a>
                     <a href="#"> <i class="fas fa-laugh-squint"></i> </a>
                     <a href="#"> <i class="fas fa-laugh"></i> </a>
                     <a href="#"> <i class="fas fa-kiss-wink-heart"></i> </a>
                     <a href="#"> <i class="fas fa-laugh-beam"></i> </a>
                     <a href="#"> <i class="fas fa-laugh-wink"></i> </a>
                   </div>
                </div>
                <div class="bottom-comment">
                   <div class="pic-box-d2">
                      <img src="<?php echo base_url();?>assets/images/men.jpg" alt="pic3">
                    
                   </div>
                   <div class="form-group">
                      <input type="text" class="form-control">
                      <button class="submit"> <i class="fas fa-paper-plane"></i> </button>
                   </div>
                </div>
                
                
             </div>
         </div>
      </div>
      
      <div class="col-md-4 p-0">
         <div class="comon-box-d1">
            <div class="right-heading">
               <h4> Suggestions</h4>
               <div class="icons-d1">
                 <a href="#"> <span class="flaticon-bookmark"></span> </a>
                 <a href="#"> <span class="flaticon-refresh"></span> </a>
               </div>
               
            </div>
            <div class="right-qwl-slider">
               <div id="owl-demo2" class="owl-carousel owl-theme">
                   <div class="comon-items">
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d2.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a href="#myModal" role="button" class="dropdown-item" data-toggle="modal"> 
                                        Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/user-pic.jpeg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d4.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d1.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/user-pic.jpeg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                   </div>
                   
                   <div class="comon-items">
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d1.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/user-pic.jpeg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d1.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d1.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/user-pic.jpeg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                   </div>
                   
                   <div class="comon-items">
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d1.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d3.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="#"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                      <div class="itms-div">
                          <div class="pic-banner">
                            <img src="<?php echo base_url();?>assets/images/post-d2.jpg" >
                          </div>
                          <div class="ontent-area">
                          
                              <div class="right-dots">
                                  <div class="dropdown">
                                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item"  data-toggle="modal" 
                                        data-target="#exampleModal2"> Add to / remove from lists </a>
                                      </div>
                                    </div>
                              </div>
                              
                              <div class="user-post">
                                 <div class="post-pic">
                                    <img src="<?php echo base_url();?>assets/images/user-pic.jpeg" alt="pic">
                                 </div>
                                 <div class="user-text-part">
                                   <h5> Name </h5>
                                   <p> Email@gmail.com </p>
                                 </div>
                              </div>
                              
                          </div>
                      </div>
                   </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</section>   
        
      