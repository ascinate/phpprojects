<?php

   if(!defined('BASEPATH')) exit('No direct script access allowed');
 
   class Addpost extends CI_Controller
   {
		public function __construct()
		{
		  parent::__construct();
		  $this->load->database();
		  $this->load->helper('url');
		  $this->load->library('session');
		  $this->load->model('addpost_model');
		}
		
		public function index()
		{
		  $this->load->view('includes/header');
		  $this->load->view('includes/header_top');
		  $this->load->view('addpost');
		  $this->load->view('includes/footer');
		}
   }
   
?>