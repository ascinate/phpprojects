
<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>Mywazio</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600;700;900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo base_url();?>assets/css/all.min.css" />
<!--<link href="css/bootstrap-formhelpers.min.css" rel="stylesheet" media="screen">-->

<!-- custom CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css" type="text/css" media="all">

<link rel='stylesheet' id='owl.carousel-css'  href='<?php echo base_url();?>assets/css/owl.carousel.min.css' type='text/css' media='all' />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/fonts/flaticon.css">

</head>
 <body>