<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
 
   class Fanlisting extends CI_Controller
   {

    public function __construct()
    {
      parent::__construct();
      $this->load->database();
      $this->load->helper('url');
      $this->load->library('session');
      $this->load->model('fanlisting_model');

    }
	
	public function index()
    {
      
      $data['users'] = $this->fanlisting_model->get_fan_list();

       $this->load->view('includes/header');
       $this->load->view('includes/header_top');
       $this->load->view('fanlisting',$data);
       $this->load->view('includes/footer');
    }
    

}
?>