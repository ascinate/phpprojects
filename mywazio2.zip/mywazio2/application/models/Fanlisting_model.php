<?php
	class Fanlisting_model extends CI_model
	{

		 public function get_fan_list()
		{
			$query=$this->db->query("select * from `user_master`");
			return $query->result();
		}
	}
	?>