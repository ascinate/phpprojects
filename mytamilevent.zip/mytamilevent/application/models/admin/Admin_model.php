<?php
	class Admin_model extends CI_model
	{
	   public function login()
	   {
		  $email = $this->input->post('email');
		  $pass = $this->input->post('password');
		  
		  $this->db->select('*');
		  $this->db->from('admin_master');
		  $this->db->where('email',$email);
		  $this->db->where('password',$pass);
	  
		  if($query=$this->db->get())
		  {
			 return $query->result_array();
		  }

		  else
		  {
			return false;
		  }
		 
	   }

	   public function user_insert($data)
	   {
		  $query =$this->db->insert('user_master',$data);
	   }

	   public function get_user_list()
	   {
			$query=$this->db->query("select * from `user_master`");
			return $query->result();
	   }

	   public function get_user_data($id)
	   {
			$this->db->select('*');
			$this->db->from('user_master');
			$this->db->where('id', $id);
			$query = $this->db->get();
			return $query->result();
	    }

	   public function update_user($id, $data)
	   {
			$this->db->where('id', $id);
			$query = $this->db->update('user_master', $data); 
	   }

	   public function delete_user($id)
	   {
			$this->db->where('id', $id);
			$query = $this->db->delete('user_master'); 
	   }

	   public function get_user_value($id)
	   {
			$query=$this->db->get_where('user_master',array('id'=>$id));
			return $query->result();
	   }

	   public function update($id,$data)
	   {
			$this->db->where('id',$id);
			$this->db->update('user_master',$data);
     		redirect("admin/dashboard/users");
	   }
				
	}
?>